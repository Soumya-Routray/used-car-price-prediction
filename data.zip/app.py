"""
app.py — Streamlit UI for the Used Car Price Prediction model.

Run locally:
    streamlit run app.py

The app loads the trained pipeline from models/best_model.joblib
(preprocessing + model bundled together, so raw inputs go straight in).
"""

import joblib
import pandas as pd
import streamlit as st

MODEL_PATH = "models/best_model.joblib"

BRANDS = [
    'Acura', 'Alfa', 'Aston', 'Audi', 'BMW', 'Bentley', 'Bugatti', 'Buick',
    'Cadillac', 'Chevrolet', 'Chrysler', 'Dodge', 'FIAT', 'Ferrari', 'Ford',
    'GMC', 'Genesis', 'Honda', 'Hummer', 'Hyundai', 'INFINITI', 'Jaguar',
    'Jeep', 'Karma', 'Kia', 'Lamborghini', 'Land', 'Lexus', 'Lincoln',
    'Lotus', 'Lucid', 'MINI', 'Maserati', 'Maybach', 'Mazda', 'McLaren',
    'Mercedes-Benz', 'Mercury', 'Mitsubishi', 'Nissan', 'Plymouth',
    'Polestar', 'Pontiac', 'Porsche', 'RAM', 'Rivian', 'Rolls-Royce',
    'Saab', 'Saturn', 'Scion', 'Subaru', 'Suzuki', 'Tesla', 'Toyota',
    'Volkswagen', 'Volvo', 'smart'
]
FUEL_TYPES = ['Gasoline', 'Diesel', 'Hybrid', 'Plug-In Hybrid', 'E85 Flex Fuel', 'Electric', 'Unknown']
TRANSMISSIONS = [
    'Automatic', 'A/T', 'M/T', 'Manual', 'CVT Transmission',
    '6-Speed A/T', '7-Speed A/T', '8-Speed A/T', '9-Speed A/T', '10-Speed A/T',
    'Transmission w/Dual Shift Mode'
]


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


def main():
    st.set_page_config(page_title="Used Car Price Predictor", page_icon="🚗", layout="centered")
    st.title("🚗 Used Car Price Predictor")
    st.write(
        "Enter a car's details below and get an estimated resale price from a "
        "model trained on ~4,000 real used-car listings."
    )

    model = load_model()

    col1, col2 = st.columns(2)

    with col1:
        brand = st.selectbox("Brand", sorted(BRANDS))
        model_year = st.number_input("Model Year", min_value=1990, max_value=2025, value=2019, step=1)
        milage = st.number_input("Mileage (miles)", min_value=0, max_value=400000, value=40000, step=1000)
        horsepower = st.number_input("Horsepower", min_value=50, max_value=1200, value=250, step=10)
        engine_size_l = st.number_input("Engine Size (Liters)", min_value=0.5, max_value=8.0, value=2.0, step=0.1)

    with col2:
        fuel_type = st.selectbox("Fuel Type", FUEL_TYPES)
        transmission = st.selectbox("Transmission", TRANSMISSIONS)
        accident = st.radio("Accident Reported?", ["No", "Yes"], horizontal=True)
        clean_title = st.radio("Clean Title?", ["Yes", "No"], horizontal=True)

    if st.button("Predict Price", type="primary"):
        car_age = 2024 - model_year
        sample = pd.DataFrame([{
            "milage": milage,
            "car_age": car_age,
            "horsepower": horsepower,
            "engine_size_l": engine_size_l,
            "brand": brand,
            "fuel_type": fuel_type,
            "transmission": transmission,
            "accident_reported": 1 if accident == "Yes" else 0,
            "clean_title_flag": 1 if clean_title == "Yes" else 0,
        }])

        prediction = model.predict(sample)[0]
        st.success(f"### Estimated Price: ${prediction:,.0f}")
        st.caption(
            "This is an estimate from a machine learning model trained on historical "
            "listings — actual market prices may vary."
        )


if __name__ == "__main__":
    main()
